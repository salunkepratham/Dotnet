﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    class Program
    {
        static void Main()
        {
            Base b1 = new Base();
            b1.Display();
            Base.Display1();            //static method call using classs name without creating object
            Console.ReadLine();
        }
    }
    public class Base
    {
        int a;
        static int b;
        public Base()
        {
            a = 10;
            b = 20;
        }
        public void Display()
        {
            Console.WriteLine("a="+a);
            Console.WriteLine("b=" + b);
        }
        //static method cant acess non static variable directly
        public static void Display1()
        {
            Console.WriteLine("b=" + b);
        }
    }
}

namespace Accessspecifier
{
    class Program
    {
        static void Main()
        {
            
        }
    }
    public class Base
    {
      public int Public;
      protected 
    }
}
