﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class Employee
    {
        static void Main()
        {
            Emp obj = new Emp();
            obj.Invalid += Obj_Invalid;
            obj.Invalid1 += Objt_Invalid1;
            try
            {
                
                Console.Write("Enter Eno :");
                obj.ENO = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                
                Console.WriteLine(ex.Message);
            }
            try
            {
                Console.Write("Enetr emp name :");
                obj.EName = Console.ReadLine();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            //event handler 
            Console.Write("Enter the basic :");
            obj.Basic = Convert.ToDecimal(Console.ReadLine());

            Console.Write("Enter the Dno:");
            obj.DNO = Convert.ToInt16(Console.ReadLine());

            Console.ReadLine();
        }

        private static void Objt_Invalid1(string s)
        {
            Console.WriteLine(s);
        }

        private static void Obj_Invalid()
        {
            Console.WriteLine("Basic Between 20000 and 50000");
        }
    }
}
public delegate void InvalidEvent();
public delegate void InvalidEveent(string s);
public class Emp
{
    public event InvalidEvent Invalid;
    public event InvalidEveent Invalid1;
    int eNo;
    string eName;
    decimal basic;
    short dNo;

    #region 
    public int ENO
    {
        set
        {
            if (value > 0)
                eNo = value;
            else
                throw new Exception("Value must be Positive");
        }
        get
        {
            return eNo;
        }
    }
    public string EName
    {
        set
        {
            if (value == "")
                throw new Exception("String should not null");

            else
                eName = value;
        }
        get
        {
            return eName;
        }
    }
    public decimal Basic
    {
        set
        {
            if (value > 20000 && value < 50000)
                basic = value;

            else
                if(Invalid!=null)
                    Invalid();
        }
        get
        {
            return basic;
        }
    }
    public short DNO
    {
        set
        {
            if (value > 0)
                dNo = value;

            else
                Invalid1("Number should be Positive");
        }
        get
        {
            return dNo;
        }
    }
    #endregion
}
