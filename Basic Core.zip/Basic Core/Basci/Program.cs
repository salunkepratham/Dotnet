﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Basci
{
    class Program
    {
        static void Main2()
        {
            int sum;
            Class1 obj = new Class1();
            obj.Display();
            // obj.Display1(2, 3, "pratham");
            // obj.Display2(5,6,"shri");
            sum =obj.Display3(c: "my");      //named parameter
            Console.WriteLine("Sum=" + sum);
            sum = obj.Display3(2, 3, "Hii");
            Console.WriteLine("Sum="+sum);
            Console.ReadLine();
        }
        static void Main()
        {
            Class2 obj = new Class2();
            obj.Seti(100);
            Console.WriteLine(obj.Geti());

            obj.P1=200;
            Console.WriteLine(obj.P1);

            obj.P3 = 2;
            Console.WriteLine(obj.P3);
            Console.ReadLine();
        }
       }
}
public class Class1
{
    int a;          //variables and methods are private by default 
    int b;          //having default values zero
    string c;
    public Class1()
    {
        a = 10;
        b = 20;
        c = "ganesh";
    }
    public void Display()
    {
        Console.WriteLine("a=" + a);
        Console.WriteLine("b=" + b);
        Console.WriteLine("c=" + c);
    }
    public void Display1(int p, int q, string r)
    {
        a = p;
        b = q;
        c = r;
        Console.WriteLine("a=" + a);
        Console.WriteLine("b=" + b);
        Console.WriteLine("c=" + c);
    }
    public void Display2(int a, int b, string c)
    {
        this.a = a;
        this.b = b;
        this.c = c;
        Console.WriteLine("a=" + a);
        Console.WriteLine("b=" + b);
        Console.WriteLine("c=" + c);
    }
    public int Display3(int a = 0, int b = 0, string c = "")
    {
        this.c = c;
        Console.WriteLine("c=" + c);
        return a + b;
    }
}
public class Class2
{
    #region Variables
    private int i;
    public void Seti(int value)
    {
        i = value;
    }
    public int Geti()
    {
        return i;
    }
    #endregion

    #region Properties
    private int p1;

    public int P1
    {
        set {
            p1 = value;
        }
        get { return p1; }
    }

    //automatic property --- compiler generates a private variable and also code for get and set
    //to do --- create readonly property
    //to do --- create writeonly property
    public int P3
    {
        set;get;
    }
    #endregion
}


